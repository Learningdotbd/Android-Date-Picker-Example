package com.ldb.learninddotbd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    DatePicker date_piker;
    Button result_button;
    TextView text_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text_view=(TextView)findViewById(R.id.text_view);
        date_piker=(DatePicker)findViewById(R.id.date_piker);
        result_button=(Button)findViewById(R.id.result_button);
        result_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_view.setText("Selected Date: "+ date_piker.getDayOfMonth()+"/"+ (date_piker.getMonth() + 1)+"/"+date_piker.getYear());
            }
        });
    }
}
// Thanks for visiting Learning dot bd